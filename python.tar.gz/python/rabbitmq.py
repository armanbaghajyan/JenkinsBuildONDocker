import pika
import smtplib

def sent_email(msbody):
    smtp_srv = 'smtp.gmail.com'
    send_from = 'sender gamil account'
    passwd = 'password'
    send_to = 'receiver email'
    message = 'Subject: RabbitMQ Jenkins.\nBuild Status\n {0}\n'.format(msbody)
    smtpObj = smtplib.SMTP(smtp_srv, 587)
    smtpObj.ehlo()
    smtpObj.starttls()
    smtpObj.login(send_from, passwd )
    smtpObj.sendmail(send_from, send_to, str(message))
    smtpObj.quit()

connection = pika.BlockingConnection(pika.ConnectionParameters(host='rabbitmq'))
channel = connection.channel()

channel.queue_declare(queue='jenkins')

def callback(ch, method, properties, body):
    print(" [x] Received %r" % body)
    sent_email(body)

channel.basic_consume(callback,
                      queue='jenkins',
                      no_ack=True)


print(' [*] Waiting for messages. To exit press CTRL+C')
channel.start_consuming()
